
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

export const analyzeMedicationImage = async (base64Image: string) => {
  if (!API_KEY) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const prompt = `Analyze this medication label carefully. Extract the following details:
  1. Medication Name
  2. Dosage (e.g., "1 tablet")
  3. Frequency/Timing periods: Determine if it should be taken in the Morning (เช้า), Midday (กลางวัน), Evening (เย็น), or Bedtime (ก่อนนอน).
  4. Any special instructions (e.g., "After meal").
  
  Please provide the response in Thai where applicable.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        { text: prompt },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: 'Name of the medication' },
          dosage: { type: Type.STRING, description: 'Dosage amount' },
          instruction: { type: Type.STRING, description: 'Meal timing or warnings' },
          periods: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.STRING,
              description: 'One of: morning, midday, evening, bedtime'
            },
            description: 'List of recommended periods'
          }
        },
        required: ["name", "dosage", "instruction", "periods"]
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}');
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    return null;
  }
};
